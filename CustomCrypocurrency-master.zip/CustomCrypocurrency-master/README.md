sorry i'm working on a readme atm \
checkout blockchain.py inside the gymcoin folder to see implementation \
Read more about this project here: https://medium.com/@nathan_149/making-my-own-cryptocurrency-from-scratch-42e05d4460c2
if you "pip install" all the dependencies in blockchain.py, and then run run.py on one terminal and run2.py on another terminal it should work!
